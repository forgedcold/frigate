import logging
import os
import tempfile
import time
import unittest
from types import SimpleNamespace
from unittest.mock import MagicMock

from peewee_migrate import Router
from playhouse.sqlite_ext import SqliteExtDatabase
from playhouse.sqliteq import SqliteQueueDatabase

from frigate.models import Recordings
from frigate.test.const import TEST_DB, TEST_DB_CLEANUPS
from frigate.tier_migrator import StorageTierMigrator


class TestStorageTierMigrator(unittest.TestCase):
    def setUp(self):
        migrate_db = SqliteExtDatabase("test.db")
        del logging.getLogger("peewee_migrate").handlers[:]
        router = Router(migrate_db)
        router.run()
        migrate_db.close()
        self.db = SqliteQueueDatabase(TEST_DB)
        self.db.bind([Recordings])
        self.test_dir = tempfile.TemporaryDirectory()

    def tearDown(self):
        if not self.db.is_closed():
            self.db.close()

        self.test_dir.cleanup()

        for file in TEST_DB_CLEANUPS:
            try:
                os.remove(file)
            except OSError:
                pass

    def _migrator(self) -> StorageTierMigrator:
        config = SimpleNamespace(
            storage=SimpleNamespace(migration_interval=300, migration_timeout=5)
        )
        return StorageTierMigrator(config, MagicMock())

    def _insert_recording(self, path: str) -> Recordings:
        now = time.time()
        return Recordings.create(
            id="recording-1",
            camera="front_door",
            path=path,
            start_time=now - 20,
            end_time=now - 10,
            duration=10,
            motion=True,
            objects=True,
            segment_size=8,
        )

    def test_migrate_segment_updates_db_after_copy(self):
        hot_dir = os.path.join(self.test_dir.name, "hot")
        archive_dir = os.path.join(self.test_dir.name, "archive")
        source_path = os.path.join(hot_dir, "2026-04-10", "front_door", "00.00.mp4")
        expected_dest = os.path.join(
            archive_dir, "2026-04-10", "front_door", "00.00.mp4"
        )
        os.makedirs(os.path.dirname(source_path))

        with open(source_path, "wb") as source_file:
            source_file.write(b"recording-data")

        recording = self._insert_recording(source_path)

        assert self._migrator()._migrate_segment(recording, hot_dir, archive_dir)

        assert not os.path.exists(source_path)
        assert os.path.exists(expected_dest)
        with open(expected_dest, "rb") as dest_file:
            assert dest_file.read() == b"recording-data"

        updated = Recordings.get(Recordings.id == recording.id)
        assert updated.path == expected_dest

    def test_migrate_segment_timeout_keeps_hot_recording_and_db_path(self):
        hot_dir = os.path.join(self.test_dir.name, "hot")
        archive_dir = os.path.join(self.test_dir.name, "archive")
        source_path = os.path.join(hot_dir, "2026-04-10", "front_door", "00.00.mp4")
        os.makedirs(os.path.dirname(source_path))

        with open(source_path, "wb") as source_file:
            source_file.write(b"recording-data")

        recording = self._insert_recording(source_path)
        migrator = self._migrator()
        migrator._run_filesystem_task = MagicMock(return_value=(False, {}, True))

        assert not migrator._migrate_segment(recording, hot_dir, archive_dir)

        assert os.path.exists(source_path)
        updated = Recordings.get(Recordings.id == recording.id)
        assert updated.path == source_path
        assert migrator._is_tier_in_backoff(archive_dir)
